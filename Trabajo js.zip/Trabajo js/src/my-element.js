/**
 * Componente principal que renderiza contenido html
 */

import { LitElement, html } from "lit-element";


export class MyElement extends LitElement {
  // constructor
  constructor(){
    super();
    this.saludo = 'Mundo';
  }
  
  //metodo static
  static get properties(){
    return {
      saludo:{
        type: String
      }
    }
  }
  
  
  //funcion para cambiar el valor
  setValue(nombre){
    this.saludo = nombre;
  }
  
  render () {
    return html `
    <h1>My element ${this.saludo}</h1>
    <button @click=${()=>this.setValue('Diego Manrique')}>Cambiar nombre</button>
    
    `
  }
}

customElements.define('my-element', MyElement);